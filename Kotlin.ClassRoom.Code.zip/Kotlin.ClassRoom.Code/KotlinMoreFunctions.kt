
package learnKotlin

/*
class MyString extend String {
	String toUpper() {
		super.convertToUpper()
	}
}

MyString string = new MyString()
string.toUpper()
*/

fun creatingCollectionsInKotlin() {
	val set = hashSetOf(1, 70, 90)
	val list = arrayListOf(1, 70, 90)
	val map = hashMapOf(1 to "One", 7 to "Seven", 90 to "Ninety")

	println(set)
	println(set.javaClass)
	
	println(list)
	println(list.javaClass)
	
	println(map)
	println(map.javaClass)
}

fun lastCharOld(string: String) = string.get(string.length - 1)

//Extension Function
fun String.lastChar() = this.get(this.length - 1)

fun playWithLastChar() {
	println(lastCharOld("Penang"))
	println("Penang".lastChar())
}


fun <T> joinToStringOld(
	collection: Collection<T>,
	seperator: String,
	prefix: String,
	postfix: String
): String {

	val result = StringBuilder(prefix)

	for ( (index, element) in collection.withIndex() )  {
		if ( index > 0 ) result.append(seperator)
		result.append(element)
	}
	result.append(postfix)
	return result.toString()
}

//Write Code For Readilbility
//Write Code For Changebility
//Refactoring Is Easy/Possible
//Focus on Coherence/Consistency Code


fun <T> Collection<T>.joinToString(
	seperator: String = ", ",
	prefix: String = "",
	postfix: String = ""
): String {

	val result = StringBuilder(prefix)

	for ( (index, element) in this.withIndex() )  {
		if ( index > 0 ) result.append(seperator)
		result.append(element)
	}
	result.append(postfix)
	return result.toString()
}

// Don't Write Code
// Write Culture
//	Want to Start Culture
//. 	Start with Names
//		Names Carried -> Ideas 
//	It Brings Coherency Test

// fun <T> Collection<T>.join(
// 	seperator: String = ", ",
// 	prefix: String = "",
// 	postfix: String = ""
// ) = joinToStringOld(seperator, prefix, postfix)


fun playWithJoinToString() {
	val list = listOf(1, 2, 2, 3, 4)
	println(joinToStringOld(list, ":", "[", "]"))
	println(list.joinToString(" : ", " [ ", " ] "))
	println(list.joinToString())
	println(list.joinToString(" - "))
	println(list.joinToString(" - ",  " ++ "))
	println(list.joinToString(" - ",  " ++ ", " %% "))

//	println(list.join(" - ",  " ++ ", " %% "))
}


// KotlinMoreFunctions.kt:111:15: error: this type is final, so it cannot be inherited from
// class Button: View() {
//               ^
// KotlinMoreFunctions.kt:112:6: error: 'click' hides member of supertype 'View' and needs 'override' modifier
// 	fun click() = println("Button Clicked!")
//      ^
// KotlinMoreFunctions.kt:116:25: error: type mismatch: inferred type is Button but View was expected
// 	val viewObject: View = Button()
//                         ^
// KotlinMoreFunctions.kt:117:2: error: unresolved reference: view
// 	view.click()


open class View {
	open fun click() = println("View Clicked!")
}

class Button : View() {
	override fun click() = println("Button Clicked!")
	fun magic() = println("Magic At Button!")
}

//0. Type Matching 
//1. Mapping Table Look Up For Message Entry
//2. Lookup Order For Message Entries
//3. Binding of Message To Method
//4. Invocation of Mehod

fun View.showOff() = println("I am View!")
fun Button.showOff() = println("I am Button!")

//Extension Prooperties
//Readonly Property
val String.lastChar: Char 
	get() = get(length -1 )

//Read Write Property
var StringBuilder.lastChar: Char
	get() = get(length -1 )
	set(value: Char) {
		this.setCharAt(length - 1, value)
	}

/*
//BAD CODE
try:
 	result = quotient / divisior
catch:

finally:

//GOOD CODE
if (divisior.isNotZero())
 	result = quotient / divisior
else:
*/

//Validation To Be Done By Try Catch
//	Validation Related To Busines Logic Do with if-else
//	

class User(val id: Int, val name: String, val address: String)

//DRY
//Don't Repeat Yourself!

fun saveUser1(user: User) {
	if (user.name.isEmpty()) { //
		throw IllegalArgumentException("Empptyines...")
	}

	if (user.address.isEmpty()) {
		throw IllegalArgumentException("Empptyines...")
	}

	//SAVE THE USER IN PERSISTANCE STORE
}

/*
class SaveUser() {
	fun f1() {

	}
}
*/

fun saveUser2(user: User) {
	fun validate(user: User, value: String, fieldName: String) {
		if (value.isEmpty()) { //
			throw IllegalArgumentException("$user -> Emptiness... $fieldName")
		}

		println("Validated: ${user.name} ")
	}  

	validate(user, user.name, "Name")
	validate(user, user.address, "Name")

	//SAVE THE USER IN PERSISTANCE STORE
}

fun User.save() {
	fun validate(value: String, fieldName: String) {
		if (value.isEmpty()) { //
			throw IllegalArgumentException("Emptiness... $fieldName")
		}

		println("Validated: $value ")
	}  

	validate(this.name, "Name")
	validate(this.address, "Name")

	//SAVE THE USER IN PERSISTANCE STORE
}


fun playWithSaveUser() {
	// val user1 = User(1, "Ali", "Penang")
	// val user2 = User(1, "Mark", "Kuala Lumpur")
	// saveUser(user1)
	// saveUser(user2)
}

fun playWithViews() {
	val viewObject: View = Button()
	viewObject.click()
	viewObject.showOff()

	val buttonObject: Button = Button()
	buttonObject.magic()
	buttonObject.showOff()
}

//KotlinMoreFunctions.kt:132:13: error: unresolved reference: magic
// viewObject.magic()
	//viewObject.magic()

//1. Function Polymorphism - Mechanism is Default Arguments
fun something(a: Int = 0, b: Int = 0) = a + b

fun playWithSomething() {
	println(something(10))
	println(something(10, 11))

	println(something( b = 11 ))
	println(something( b = 11, a = 10 ))
}

fun sum(a: Int, b:Int ) = a + b
fun sub(a: Int, b:Int ) = a - b

//2. Function Polymorphism - Mechanism is Passing Behaviour To Behaviour
fun calculator(a: Int, b: Int, operation: (Int, Int) -> Int ): Int {
	return operation(a, b)
}

fun playWithCalculator() {
	print("Result: ")
	println(calculator(10, 20, ::sum))
	print("Result: ")
	println(calculator(10, 20, ::sub))
}

//3. Function Polymorphism - Mechanism is Varidiac Arguments
fun average(vararg input: Int): Float {
    var sum = 0.0f
    for (item in input) {
        sum += item
    }
    return (sum / input.size)
}

fun playWithAverage() {
	println(average(1, 2, 3) )
	println(average(1, 2, 3, 4, 5) )
}

interface Clickable {
    fun click()
}

class Button : Clickable {
    override fun click() = println("I was clicked")
}

fun functionButtonClick() {
    Button().click()
}


fun main() {

	println("\nFunction: creatingCollectionsInKotlin")
	creatingCollectionsInKotlin()

	println("\nFunction: lastChar")
	playWithLastChar()

	println("\nFunction: playWithJoinToString")
	playWithJoinToString()

	println("\nFunction: playWithViews")	
	playWithViews()

	println("\nFunction: playWithSomething")	
	playWithSomething()
	
	println("\nFunction: playWithCalculator")	
	playWithCalculator()

	println("\nFunction: playWithAverage")	
	playWithAverage()
	

	// println("\nFunction: ")	
	// println("\nFunction: ")	
	// println("\nFunction: ")	
	// println("\nFunction: ")	

}
