#include <stdio.h>

typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
	void (*sing)();
} Human;

void dandut() {
	printf("Do Dandut...");
}

void kangunge() {
	printf("Do Kanunge......");
}

int main() 
{
	//Constructur
	//Human h = new Human(10, "Ali");
	Human h = { 10, "Najib", dandut, kangunge };
	printf("\n Values %d %s", h.id, h.name );
	h.dance();
	h.sing();
}
