
package learnKotlin

//Static Scenarios

/*
1. as Constants using static at class level  - Enums/Sealed Classes/File Level Members
2. Singleton. - Special Case Factory Methods
3. static main - Java Messed Up Everything Starts With Class
4. Utility Methods - Java Messed Up Everything Starts With Class
5. Inner Classed To Made Nested Class - - Java Messed Up Nested Classed Are Inner By Default
	reference to object on nested classes static
	To Circular Reference Problem
6. Object Counters - Object Manager Class 
7. Object Communication - Communication Frameworks - Pub-Sub

8. Visibility Of Context and Lifetime -   ?????

9. Unit Tests - Java Messed Up Everything Starts With Class
*/

//interface Expr

enum class Color(val r: Int, val g: Int, val b: Int) {
	RED(255, 0, 0), GREEN(0, 255, 0), BLUE(0, 0, 255)
}


sealed class Expr { }
class Num(val value: Int) : Expr()
class Sum(val left: Expr, val right: Expr) : Expr()

// sealed class Expr { 
// 	class Num(val value: Int) : Expr()
// 	class Sum(val left: Expr, val right: Expr) : Expr()
// }

fun eval(e: Expr): Int =
    when (e) {
        is Num -> e.value
        is Sum -> eval(e.right) + eval(e.left)
        //is Expr -> 0
        // else ->
        //     throw IllegalArgumentException("Unknown expression")
    }

fun functionEval() {
    println(eval(Sum(Sum(Num(1), Num(2)), Num(4))))
}

class Outer {
	//Inner Class will capture Outer Context
	//Default in Kotlin is Nested Classes which are not inner.
   inner class Inner {
       fun getOuterReference(): Outer = this@Outer
   }
}


class User(val nickname: String, val isSubscribed: Boolean = true) 

fun objectCreation() {
    val alice = User("Alice")
    println(alice.isSubscribed)
    val bob = User("Bob", false)
    println(bob.isSubscribed)
    val carol = User("Carol", isSubscribed = false)
    println(carol.isSubscribed)
}

class LengthCounter {
    var counter: Int = 0
    	private get
        private set

    fun addWord(word: String) {
        counter += word.length
    }
}

fun changingAccessorVisibility() {
    val lengthCounter = LengthCounter()
    lengthCounter.addWord("Hi!")
    println(lengthCounter.counter)
}

fun main() {
	println("Function: functionEval")
	functionEval()

	println("Function: functionEval")
	changingAccessorVisibility()
}

