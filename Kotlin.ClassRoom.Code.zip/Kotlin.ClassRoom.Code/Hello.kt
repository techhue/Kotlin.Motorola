
package learnKotlin


int a = 32000;
int b = 32000;

int r = sum(a, b);

//BAD CODE
int sum(int a, int b) {
	return a + b;
}


//WRITE GOOD CODE
int sum(int a, int b) {
	// Return Valid SUM
	// Otherwise
	//	PRINT Cann't calculate Sum
}

#include <limits.h>

//Respect Type Like God
// This is called Type Safety


int sum(signed int si_a, signed int si_b) {
  signed int result;
  if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
      ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
    /* Handle error */
  } else {
    result = si_a + si_b;
  }
  /* ... */
  return result;
}


fun helloWorld() {
	print("Hello World!")
}

fun main() {
	helloWorld()
}



