package learnKotlin

interface Superpower {
	fun fly()
	fun saveWorld()
}

class SpidermanBad : Superpower {
	override fun fly() {
		println("Fly Like Spiderman!")
	}

	override fun saveWorld() {
		println("SaveWorld Like Spiderman!")
	}
}

class Spiderman : Superpower {
	override fun fly() {
		println("Fly Like Spiderman!")
	}

	override fun saveWorld() {
		println("SaveWorld Like Spiderman!")
	}
}

class Superman : Superpower {
	override fun fly() {
		println("Fly Like Superman!")
	}

	override fun saveWorld() {
		println("SaveWorld Like Superman!")
	}
}

class Heman : Superpower {
	override fun fly() {
		println("Fly Like Heman!")
	}

	override fun saveWorld() {
		println("SaveWorld Like Heman!")
	}
}

class Wonderwoman: Superpower {
	override fun fly() {
		println("Fly Like Wonderwoman!")
	}

	override fun saveWorld() {
		println("SaveWorld Like Wonderwoman!")
	}
}

/*
class Human : Spiderman {
	override fun fly() {
		super.fly()
	}

	override fun saveWorld() {
		super.saveWorld()
	}
}
*/

//Composite Design Pattern
	//Delegation To Delegate

class Human {
	//power is delegate
	var power: Superpower = null

	fun fly() {
		power?.fly()
	}

	fun saveWorld() {
		power?.saveWorld()
	}
}

fun main() {
	val hh = Human()
	hh.fly()
	hh.saveWorld()

	val sp = Spiderman()
	sp.fly()
	sp.saveWorld()

	val su = Superman()
	su.fly()
	su.saveWorld()

	val h = Human()

	// h.power = SpidermanBad()
	h.power = Spiderman()
	h.fly()
	h.saveWorld()

	h.power = Superman()
	h.fly()
	h.saveWorld()

	h.power = Heman()
	h.fly()
	h.saveWorld()

	h.power = Wonderwoman()
	h.fly()
	h.saveWorld()

}

