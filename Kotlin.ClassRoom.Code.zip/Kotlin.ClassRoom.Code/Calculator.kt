package learnKotlin

// /*
// //VALID SUM
// #include <limits.h>
 
// #define SUM_ERROR -1

// typdef struct result_type {
// 	int value;
// 	int error;
// } Result;

// Result sum(signed int si_a, signed int si_b) {
//   Result result;
//   //RESPECTING GOD/TYPE
//   if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
//       ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
//     /* Handle error */
// 		//printf("Cann't Do Sum... Invalid Inputs")
// 	//Tell World I cann't Calculate Sum
// 		result.error = -1;
// 		return SUM_ERROR;
//   } else {
//   		result.error = 0;
//     	result.value = si_a + si_b;
//   }

//   return result;
// }

// Result output = sum(a, b);
// if output.error != -1 {

// }



// /* NOT TESTABLE AT ALL
// int sum(int a, int b) {
// 	return a + b;
// }
// */

// //NEVER EVER MESS WITH GOD!
// //YOU CANN'T QUESTION GOD!
// 	//You Can Test GOD

// long expectedValue = 64000;
// int result = sum(32000, 32000);

// ASSERT( result, expectedValue) ;

// Atleast 1 Unit Test -> Functional Testing
fun sum(a: Int, b: Int ) = a + b

// Atleast 1 Unit Test -> Functional Testing
fun sub(a: Int, b: Int ) = a - b

// Atleast 1 Unit Test -> Functional Testing
fun mul(a: Int, b: Int ) = a * b

//
//2. Function Polymorphism - Mechanism is Passing Behaviour To Behaviour
// Atleast 1 Unit Test -> Functional Testing
// Integartion Test -> Only one sufficient

fun calculator(a: Int, b: Int, operation: (Int, Int) -> Int ): Int {
	return operation(a, b)
}

fun playWithCalculator() {

	val func: (Int, Int) -> Int = { a: Int, b: Int -> a + b }
	// val func1: (Int, Int) -> Int = { a , b -> a + b }
	// val func2 = { a: Int, b: Int -> a + b }

	println("Function : calculator")
	println(calculator(10, 20, ::sum))
	
	println("Function : calculator")
	println(calculator(10, 20, func))

}

fun doSomething(talent: Int) : () -> String {
	// fun doDancing() = "Do Dancing..."
	// fun doSinging() = "Do Singing..."

	// { Arugments -> Body }
	// {  Body }

	val doDancing = { "Do Dancing..." }
	val doSinging = { "Do Singing..." }

	//return if (talent == 0) ::doDancing else ::doSinging
	return if (talent == 0) doDancing else doSinging
}

fun playWithDoSomething() {
	val someone: (Int) -> () -> String = ::doSomething
	
	val something: () -> String = someone(0)
	println(something())
}

data class Person(val name: String, val age: Int, val marks: Int)

fun playWithLambda() {
	val people = listOf(Person("Bob", 60, 80), Person("Alice", 29, 90), 
		Person("Ang", 31, 100))

	//list<Person>.maxBy( predicate : (Person) -> Int )
	//val max1 = people.maxBy(  { p: Person -> p.age }  )

	//Trailing Lambda means If Function has last argument lambda
	// Then paranthese can be skipped

	//val max2 = people.maxBy { p: Person -> p.age } 
	//println(max1)
	//println(max2)

	val maxAge = people.maxBy { 
		it.age 
	} 
	
	val maxMarks = people.maxBy { 
		it.marks
	} 
	
	println(maxAge)
	println(maxMarks)
}

fun playWithRecievers() {
	// Person.reciever = 

	val receiver: Person.() -> Unit = { println("Hello $name") }
	receiver(Person("Bob", 60, 80))

	val someone: (Person) -> Unit = { p: Person -> println("Hi ${p.name}") }
	val someoneone: (Person) -> Unit = { println("Hi ${it.name}") }
	someone(Person("Bob", 60, 80))
	someoneone(Person("BobBob", 60, 80))

	// Person("Mary", 60, 80).receiver()
	//Person("Mary", 60, 80).()

	//person.reciever()
}

fun playWithUnit(): Unit {
	val x = 0
	val something = if (x == 0) { 

	} else {
	 	10
	}

	println(something)
}

fun playWithUnitType () {
	val somesome: () -> Unit = ::playWithUnit
	somesome()
}


fun main() {
	println("\nFunction: playWithCalculator")
	playWithCalculator()

	println("\nFunction : playWithDoSomething")
	playWithDoSomething()

	println("\nFunction: playWithLambda")
	playWithLambda()

	println("\nFunction : playWithRecievers")
	playWithRecievers()

	println("\nFunction : playWithUnit")
	playWithUnit()

	println("\nFunction: playWithUnitType")
	playWithUnitType()
}


