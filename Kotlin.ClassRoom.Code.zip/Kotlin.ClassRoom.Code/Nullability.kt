
package learnKotlin

class Address0(val streetAddress: String, val zipCode: Int,
              val city: String, val country: String)

class Company0(val name: String, val address: Address0?)

class Person0(val name: String, val company: Company0?)

fun Person0.countryName(): String {
   val country = this.company?.address?.country
   // return if (country != null) country else "Unknown"
   return country ?: "Unknown"
}

fun safeCallOperator2() {
    val person = Person0("Dmitry", null)
    println(person.countryName())
}

//Elvis Operator ?: DefaultVaiue
// ?.     ?: DefaultVaiue

fun strLenSafe1(s: String?): Int = s?.length ?: 0

fun evlisOperator() {
    println(strLenSafe1("abc"))
    println(strLenSafe1(null))
}



class Person2(val firstName: String, val lastName: String) {
   override fun equals(o: Any?): Boolean {
      val otherPerson = o as? Person2 ?: return false
      //val otherPerson: Person2? = o as? Person2

      return otherPerson.firstName == firstName &&
             otherPerson.lastName == lastName
   }

   override fun hashCode(): Int =
      firstName.hashCode() * 37 + lastName.hashCode()
}


fun safeCastAs() {
    val p1 = Person2("Dmitry", "Jemerov")
    val p2 = Person2("Dmitry", "Jemerov")
    println(p1 == p2)
    println(p1.equals(42))
}

//BAAAAAD VERY BAAAAAD PATTERN!
//NEVER EVER DO THIS
fun ignoreNulls(s: String?) {
    val sNotNull: String = s!!
    println(sNotNull.length)
}

fun notnullAssertions() {
    ignoreNulls("Ding Dong")

// kotlin.KotlinNullPointerException    
    // ignoreNulls(null)
}

fun sendEmailTo(email: String) {
    println("Sending email to $email")
}

fun letFunction() {
    var email: String? = "yole@example.com"

    email?.let { sendEmailTo(it) }
    email = null
    email?.let { sendEmailTo(it) }
}


fun verifyUserInput(input: String?) {
    if (input.isNullOrBlank()) {
        println("Please fill in the required fields")
    }
}

fun extensionsForNullableTypes() {
    verifyUserInput(" ")
    verifyUserInput(null)
}


data class PersonD(val name: String,
                  val age: Int? = null) {

    fun isOlderThan(other: PersonD): Boolean? {
        if (age == null || other.age == null)
            return null
        return age > other.age
    }
}

fun nullablePrimitiveTypes() {
    println(PersonD("Sam", 35).isOlderThan(PersonD("Amy", 42)))
    println(PersonD("Sam", 35).isOlderThan(PersonD("Jane")))
}

fun numberConversion() {
    val x = 1
    println(x.toLong() in listOf(1L, 2L, 3L))
}

fun numberConversion2() {
    println("42".toInt())
}


fun fail(message: String): Nothing {
    throw IllegalStateException(message)
}


fun main() {

}