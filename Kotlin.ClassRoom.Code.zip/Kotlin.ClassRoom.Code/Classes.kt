package learnKotlin

enum class PersonStatus() {

}

class Person(val id: Int, val name: String) {
	val personStatus: PersonStatus? = null

}

object Payroll {
    val allEmployees = arrayListOf<Person>()
    fun calculateSalary() {
	    for (person in allEmployees) {
	    	println(person)
	    }
	}	
} 

fun playWithSingleton() {
	Payroll.allEmployees.add(Person(1, "Ang"))
	// Payroll.allEmployees.add(Person(2, "Yen"))
	// Payroll.allEmployees.add(Person(3, "Mark"))
	Payroll.calculateSalary()
}

fun playWithEquality() {
	println( 10 + 20 )
	println( "Super" + "Magic" )

	val first  = "Super"
	val second = "Magic"
	val third = "Super"

	println(first == second )
	println(first == third )

	println(first === second )
	println(first === third )

	println( 10 == 20 )
	println( "Super"  == "Magic" )
	println( "Super"  == "Super" )
}

fun sum(a: Int, b: Int) : Int = a + b


fun playWithFunction() {
	val func1: (Int, Int) -> Int = ::sum

	//Lambda Expression
	val func2: (Int, Int) -> Int = { a: Int, b: Int -> a + b }

	println(func1( 10, 30 ))
	println(func2( 100, 300 ))

}

fun main() {
	println("Function: playWithSingleton")
	playWithSingleton()

	println("Function: playWithFunction")
	playWithFunction()
}

