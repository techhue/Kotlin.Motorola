package learnKotlin


//Type Sytem is Theorem
interface Expr
class Num(val value: Int) : Expr
class Sum(val left: Expr, val right: Expr) : Expr

//Program is Proof
fun eval(e: Expr): Int =
    when (e) {
        is Num -> e.value
        is Sum -> eval(e.right) + eval(e.left)
        is Expr -> 0
        else ->
            throw IllegalArgumentException("Unknown expression")
    }

fun functionEval() {
    println(eval(Sum(Sum(Num(1), Num(2)), Num(4))))
}

fun main() {
	functionEval()
}

