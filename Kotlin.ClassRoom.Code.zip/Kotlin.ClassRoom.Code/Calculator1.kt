package learnKotlin


//Design Towards Definition <-> Definition Driven Design
	//Physics and Mathematics, Civil Engineering


//DESIGN GOALS -> UNIVERSAL
//Design Towards Abstact Types Rather Than Concrete Types

//Emergence Property
	// Loose Coupling <-> Unitness In System

//VERY SPECIFIC
//Design Towards Interfaces Rather Than Concrete Classes

	// Design Towards What Rather Than How, Where, When, Why...



// Atleast 1 Unit Test -> Functional Testing

//Function Type is (Int, Int) -> Int
// sum is object of type (Int, Int) -> Int


fun sum(a: Int, b: Int ) = a + b

fun sum3(a: Int, b: Int, c: Int ) = a + b + c

// Atleast 1 Unit Test -> Functional Testing
fun sub(a: Int, b: Int ) = a - b

// Atleast 1 Unit Test -> Functional Testing
fun mul(a: Int, b: Int ) = a * b

//
//2. Function Polymorphism - Mechanism is Passing Behaviour To Behaviour
// Atleast 1 Unit Test -> Functional Testing
// Integartion Test -> Only one sufficient

fun calculator(a: Int, b: Int, operation: (Int, Int) -> Int ): Int {
	return operation(a, b)
}

fun playWithCalculator() {

	var functionObject: (Int, Int) -> Int = ::sum
	//functionObject = ::sum3

	val calc: (Int, Int, (Int, Int) -> Int ) -> Int = ::calculator
	
	print("Result: Calc")
	println(calc(10, 20, ::sum))
		

	println(functionObject(110, 100))



	print("Result: ")
	println(calculator(10, 20, ::sum))
	
	print("Result: ")
	//println(calculator(10, 20, ::sub))
}


fun main() {
	println("Function: playWithCalculator")
	playWithCalculator()
}


