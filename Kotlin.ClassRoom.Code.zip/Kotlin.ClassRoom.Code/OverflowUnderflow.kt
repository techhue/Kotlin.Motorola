
//@Suppress("INTEGER_OVERFLOW")
fun overflows() {
    // The following 'signed' computations all produce compiler warnings 
    // that they will lead to an overflow
    // which have been ignored

    println("*** Signed 32 bit integers ***\n")
    println(-(-2147483647 - 1))
    println(2000000000 + 2000000000)
    println(-2147483647 - 2147483647)
    println(46341 * 46341)
    println((-2147483647 - 1) / -1)


//     *** Signed 32 bit integers ***
    // -2147483648
    // -294967296
    // 2
    // -2147479015
    // -2147483648
}

