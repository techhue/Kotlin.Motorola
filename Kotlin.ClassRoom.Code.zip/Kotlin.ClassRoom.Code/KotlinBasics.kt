package learnKotlin

import java.util.Random
import java.util.TreeMap

fun maxOld(a: Int, b: Int) : Int {
	return if ( a > b ) a else b
}

fun max(a: Int, b: Int) = if ( a > b ) a else b

enum class Color(val r: Int, val g: Int, val b: Int) {
	RED(255, 0, 0), GREEN(0, 255, 0), BLUE(0, 0, 255),
	ORANGE(99,99,99), VIOLET(88,88,88), INDIGO(77,77,77),
	YELLOW(66,77,77), UNKNOWN(0, 0, 0)
}

//KotlinBasics.kt:15:16: error: 
// type mismatch: 
// inferred type is String 
// but Unit was expected

/*
fun stringForColor1(color : Color): String {
	return when (color) {
		Color.RED -> "Red Color"
		Color.GREEN -> "Green Color"
		Color.BLUE -> "Blue Color"
		Color.UNKNOWN -> "Unknown Color"
	}
}

//KotlinBasics.kt:26:38: error: 
// 'when' expression must be exhaustive, 
// add necessary 'BLUE' branch or 'else' branch instead

fun stringForColor2(color : Color) = when (color) {
		Color.RED -> "Red Color"
		Color.GREEN -> "Green Color"
		Color.BLUE -> "Blue Color"
		Color.UNKNOWN -> "Unknown Color"
		//else -> "Unknown Color"
}

fun stringForColor3(color : Color) = when (color) {
		Color.RED -> "Red Color"
		Color.GREEN -> "Green Color"
		Color.BLUE -> "Blue Color"
		Color.UNKNOWN -> "Unknown Color"
}

*/

fun getWarmth(color: Color) = when(color) {
    Color.RED, Color.ORANGE, Color.YELLOW -> "warm"
    Color.GREEN -> "neutral"
    Color.BLUE, Color.INDIGO, Color.VIOLET -> "cold"
    Color.UNKNOWN -> "Unknown Things"
}


// KotlinBasics.kt:60:37: error: type mismatch: inferred type is Color but Unit was expected
// 		setOf(Color.RED, Color.YELLOW) -> Color.ORANGE
//                                    ^
// KotlinBasics.kt:61:38: error: type mismatch: inferred type is Color but Unit was expected
// 		setOf(Color.YELLOW, Color.BLUE) -> Color.GREEN
//                                      ^
// KotlinBasics.kt:62:38: error: type mismatch: inferred type is Color but Unit was expected
// 		setOf(Color.BLUE, Color.VIOLET) -> Color.INDIGO
//                                      ^
// KotlinBasics.kt:64:11: error: type mismatch: inferred type is String but Unit was expected
// 		else -> "Unknown Color"
fun mix(c1: Color, c2: Color): Color {
	return when( setOf(c1, c2) ) {
		setOf(Color.RED, Color.YELLOW) -> Color.ORANGE
		setOf(Color.YELLOW, Color.BLUE) -> Color.GREEN
		setOf(Color.BLUE, Color.VIOLET) -> Color.INDIGO
		else -> Color.UNKNOWN
		// else -> "Unknown Color"
		// else -> throw Exception("Dirty Colors")
	}
}

// 7 Things Are Generated
// 2 Setters for Each Property
// 2 Getters for Each Property
// 2 Backing Fiield for Each Property
// 1 One Constructor -> Primary Constructor/Memberwise Initlizer
class Person( val name: String, var isMarried: Boolean )

fun playWithPerson() {
	//val person1 = Person()
	//Memberwise Initilizer -> Will Initlize All Properties
	val person = Person("Ali", true)
	println(person.name)
	println(person.isMarried)
}

// 7 Things Are Generated
// 2 Setters for Each Property
// 2 Getters for Each Property
// 2 Backing Fiield for Each Property
// 1 One Constructor -> Primary Constructor/Memberwise Initlizer
// 1 Commuted Propety Getting Generated


// height and width are Stored Properties
// class Rectangle(val height: Int, val width: Int) {
// 	//isSquare is Computed Property
// 	// val isSquare: Boolean 
// 	// 	get() {
// 	// 		return height == width
// 	// 	}
// }

class Rectangle(val height: Int, val width: Int) {
	val isSquare = height == width
}

fun playWithRectangle() {
	val rectangle = Rectangle(30, 40)
	println( rectangle.isSquare )
}

fun playWithRandomRectangle(): Rectangle {
	val random = Random()
	return Rectangle(random.nextInt(), random.nextInt())
}

interface Expr
class Num(val value: Int) : Expr
class Sum(val left: Expr, val right: Expr) : Expr

fun eval1(e: Expr) : Int {
	if (e is Num) { 
		return e.value 
	}

	//Kotlin Style - Smart Casts
	if (e is Sum) {
		return eval1(e.left) + eval1(e.right)
	}

	// if (e is Sum) {
	// 	//Do Something
	// }

	// if (e is Sum) {
	// 	//Do Nothing
	// }

	//How Smart Casts Works Internally
	//Kotlin Compiler Generates Following Java Code
	// if e.isintance(SUM)	 {
	// 	val e: Sum = Sum(e)
	// 	return eval(e.left) + eval(e.right)
	// }

	throw IllegalArgumentException("Unkown Expression...")
}


fun eval2(e: Expr) : Int {
	if (e is Num) return e.value 

	if (e is Sum) return eval2(e.left) + eval2(e.right)

	throw IllegalArgumentException("Unkown Expression...")
}


//KotlinBasics.kt:171:21: error: type checking has run 
// into a recursive problem. Easiest workaround: 
// specify types of your declarations explicitly
// else if (e is Sum) eval3(e.left) + eval3(e.right)

fun eval3(e: Expr): Int = if (e is Num) e.value 
	else if (e is Sum) eval3(e.left) + eval3(e.right)
	else throw IllegalArgumentException("Unkown Expression...")

fun playWithEval(): Int {
	return eval3(Sum(Num(10), Num(11)))
}

fun evalWhen(e: Expr): Int {
	return when (e) {
		 is Num -> e.value 
		 is Sum -> evalWhen(e.left) + evalWhen(e.right)
		 else -> throw IllegalArgumentException("Unkown Expression...")
	}
}

fun evaluate(e: Expr): Int = when (e) {
	 is Num -> e.value 
	 is Sum -> evaluate(e.left) + evaluate(e.right)
	 else -> throw IllegalArgumentException("Unkown Expression...")
}

 
fun playWithEvalWhen(): Int {
	return evalWhen1(Sum(Num(10), Num(11)))
}

//Pattern Matching... LValue can be Expression!
fun fizzBuzz(i: Int) = when  {
	i % 15 == 0 -> "FizzBuzz"
	i % 3 == 0 -> "Fizz"
	i % 5 == 0 -> "Buzz"
	else -> " $i "
}

//BEST PRACTICE
// USE foreach/for in rather than indexing loop

//Quesiton:
// Is it possible to replace indexing loop with for each loop?
 
//Indexing Loop -
/*
for (int i = 0 ; i <= n ; i++ ) {

}
*/
//For In or Foreach loop
//
fun fizzyBuzzyThings() {
	for (i in 1..10) {
		print(fizzBuzz(i))
	}
}

fun rangeProgressions() {
	for (i in 10 downTo 1 step 2) {
//		i = 9
		print(fizzBuzz(i))
	}
}

// for-in Loop is More Fundamental Than Indexing Loop
// Hence: Every Indexing Loop can be replace with for-in Loop

fun iteratingOverMaps() {
	val binaryRep = TreeMap<Char, String>()

	// c is UniCode Char Type
	for (c in 'A'..'F') {
		val binary = Integer.toBinaryString(c.toInt())
		binaryRep[c] = binary
	}

	//(letter, binary) is Tuple
	// Tuple Consists of 2 elements -> 1st is Key. 2nd is Value
	// Destructuring Operator <-> Unpacking [Python]
	for ((letter, binary) in binaryRep) {
			println("$letter = $binary")
	}
}

//Reducing Cyclomatic Commplexity
//Flat Is Better Than Nested
//Code Readibility Improves
//Bug Rates WIll Reduce Because Comprehension is Better
//Write Code For Readability
//Cognative Load Reduction

fun isLetter(c: Char)   = c in 'a'..'z' || c in 'A'..'Z'
fun isNotDigit(c: Char) = c !in '0'..'9'

fun existanceTest() {
	println(isLetter('Q'))
	println(isNotDigit('Q'))
	println(isNotDigit('0'))
}

fun recognize(c: Char) = when (c) {
    in '0'..'9' -> "It's a digit!"
    in 'a'..'z', in 'A'..'Z' -> "It's a letter!"
    else -> "I don't know…​"
}

fun usingInCheckWithWhen() {
    println(recognize('8'))
}

//Idiomatic Style Of Programming
//Pythonic Style

@Suppress("INTEGER_OVERFLOW")
fun overflows() {
    // The following 'signed' computations all produce compiler warnings 
    // that they will lead to an overflow which have been ignored

    println("*** Signed 32 bit integers ***\n")
    println(-(-2147483647 - 1))
    println(2000000000 + 2000000000)
    println(-2147483647 - 2147483647)
    println(46341 * 46341)
    println((-2147483647 - 1) / -1)

    // *** Signed 32 bit integers ***
    // -2147483648
    // -294967296
    // 2
    // -2147479015
    // -2147483648
}

fun main() {
	println("\nFunction:  maxOld")
	println(maxOld(10, 90))

	println("\nFunction: max")
	println(max(10, 90))

	// println("\nFunction: stringForColor1 ")
	// println( stringForColor1(Color.RED) )

	// println("\nFunction: stringForColor2 ")
	// println( stringForColor2(Color.RED) )

	// print("\nFunction: overflows")
	// overflows()

	println("\nFunction: getWarmth")
	println(getWarmth(Color.RED))

	println("\nFunction: mix")
	println(mix(Color.RED, Color.YELLOW))

	println("\nFunction: playWithPerson")
	playWithPerson()

	println("\nFunction: playWithRectangle")
	playWithRectangle()

	println("\nFunction: playWithEval")
	println(playWithEval())

	println("\nFunction: fizzyBuzzyThings")
	fizzyBuzzyThings()

	println("\nFunction: rangeProgressions ")
	rangeProgressions()

	println("\nFunction: iteratingOverMaps")
	iteratingOverMaps()
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}
