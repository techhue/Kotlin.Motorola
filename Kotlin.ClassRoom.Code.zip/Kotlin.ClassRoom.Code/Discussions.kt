
Welcome To Kotlin World!
_________________________________________________
Trainer: Amarjit Singh


Please complete PreTest
_________________________________________________

Pre Test URL: http://bit.ly/2Mp5DZs

Whenever you are ready!
	Just let us know.


A. Kotlin Environment Setup
_________________________________________________

1. Download Kotlin Compiler
	Kotlin Compiler Version: 1.3.41
	https://github.com/JetBrains/kotlin/releases/tag/v1.3.41
		kotlin-compiler-1.3.41.zip    43.5 MB

2. Install Kotlin Compiler
	Unzip It -> kotlin-compiler-1.3.41.zip

	Add In PATH Variable following path
		YOUR_FOLDER/kotlinc/bin

3. Test Environment
	Create Hello.kt File

	Write Following Code In Hello.kt
		package learnKotlin
		fun main() {
			print("Hello World!")
		}
	
	Compile Hello.kt with following Command
		kotlinc Hello.kt -include-runtime -d hello.jar

	Run your .jar
		java -jar hello.jar


Type As An Idea!
_______________________________________________________
	1. Type Inferencing -> Right Hand Side Value RValue
	2. Type Binding 	-> Left Hand Side LValue
	3. Type Safety  	-> Respect Like God
	4. Type Strickness -> Focing Type Safety
	
	Type Analysis	-> It Does Type Analysis At Deeper Level


Expression As An Idea!
_______________________________________________________
	In Kotlin Almost Everything is an Expression
		Expressions = Statments Having Return Value
	Functions Are First Class Citizens


Nullabiltity As An Idea!
_______________________________________________________
	Design Towards Determinism Rather Than Non Determinism
	Design Towards Defined Things Rather Than Undefined Things
	Design Towards Non Nothingness Rather Than Nothingness
	Design Towards NonNullability Rather Than Nullabiltity
	

//Static Scenarios
/*

2. Singleton. - Special Case Factory Methods

1. as Constants using static at class level  - Enums/Sealed Classes/File Level Members
3. static main - Java Messed Up Everything Starts With Class
4. Utility Methods - Java Messed Up Everything Starts With Class
5. Inner Classed To Made Nested Class - - Java Messed Up Nested Classed Are Inner By Default
	reference to object on nested classes static
	To Circular Reference Problem
6. Object Counters - Object Manager Class 
7. Object Communication - Communication Frameworks - Pub-Sub

8. Visibility Of Context and Lifetime -   ?????

9. Unit Tests - Java Messed Up Everything Starts With Class
*/


The object keyword comes up in Kotlin in a number of cases, but they all share the same core idea: the keyword defines a class and creates an instance (in other words, an object) of that class at the same time. Let’s look at the different situations when it’s used:
􏰀
-  Object declaration is a way to define a singleton.
􏰀-  Companion objects can contain factory methods and other methods that are
related to this class but don’t require a class instance to be called. Their mem-
bers can be accessed via class name.
􏰀-  Object expression is used instead of Java’s anonymous inner class.
Now we’ll discuss these Kotlin features in detail.



	

