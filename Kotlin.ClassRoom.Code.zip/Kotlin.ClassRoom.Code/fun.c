
#include <stdio.h>

int sum(int a, int b) {
	return a + b;
}

int main() {
	int a = 10;
	int *address = &a;
	int **addressOf = &address;

	int (*fptr)(int, int) = sum;
	int result = fptr(10, 20);

	printf("\nResult: %d", result);
	
	printf("\nValue is: %d %p %d\n", a, address, *address);
	printf("\nValue is: %p %p %d\n", 
		addressOf, *addressOf, **addressOf);
}
