package learnKotlin

// /*
// //VALID SUM
// #include <limits.h>
 
// #define SUM_ERROR -1

// typdef struct result_type {
// 	int value;
// 	int error;
// } Result;

// Result sum(signed int si_a, signed int si_b) {
//   Result result;
//   //RESPECTING GOD/TYPE
//   if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
//       ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
//     /* Handle error */
// 		//printf("Cann't Do Sum... Invalid Inputs")
// 	//Tell World I cann't Calculate Sum
// 		result.error = -1;
// 		return SUM_ERROR;
//   } else {
//   		result.error = 0;
//     	result.value = si_a + si_b;
//   }

//   return result;
// }

// Result output = sum(a, b);
// if output.error != -1 {

// }



// /* NOT TESTABLE AT ALL
// int sum(int a, int b) {
// 	return a + b;
// }
// */

// //NEVER EVER MESS WITH GOD!
// //YOU CANN'T QUESTION GOD!
// 	//You Can Test GOD

// long expectedValue = 64000;
// int result = sum(32000, 32000);

// ASSERT( result, expectedValue) ;

// Atleast 1 Unit Test -> Functional Testing
fun sum(a: Int, b: Int ) = a + b

// Atleast 1 Unit Test -> Functional Testing
fun sub(a: Int, b: Int ) = a - b

// Atleast 1 Unit Test -> Functional Testing
fun mul(a: Int, b: Int ) = a * b

//
//2. Function Polymorphism - Mechanism is Passing Behaviour To Behaviour
// Atleast 1 Unit Test -> Functional Testing
// Integartion Test -> Only one sufficient

fun calculator(a: Int, b: Int, operation: (Int, Int) -> Int ): Int {
	return operation(a, b)
}

fun playWithCalculator() {

	val func: (Int, Int) -> Int = { a: Int, b: Int -> a + b }
	// val func1: (Int, Int) -> Int = { a , b -> a + b }
	// val func2 = { a: Int, b: Int -> a + b }

	println("Function : calculator")
	println(calculator(10, 20, ::sum))
	
	println("Function : calculator")
	println(calculator(10, 20, func))

}

fun doSomething(talent: Int) : () -> String {
	// fun doDancing() = "Do Dancing..."
	// fun doSinging() = "Do Singing..."

	// { Arugments -> Body }
	// {  Body }

	val doDancing = { "Do Dancing..." }
	val doSinging = { "Do Singing..." }

	//return if (talent == 0) ::doDancing else ::doSinging
	return if (talent == 0) doDancing else doSinging
}

fun playWithDoSomething() {
	val someone: (Int) -> () -> String = ::doSomething
	
	val something: () -> String = someone(0)
	println(something())
}

data class Person(val name: String, val age: Int, val marks: Int)

fun playWithLambda() {
	val people = listOf(Person("Bob", 60, 80), Person("Alice", 29, 90), 
		Person("Ang", 31, 100))

	//list<Person>.maxBy( predicate : (Person) -> Int )
	//val max1 = people.maxBy(  { p: Person -> p.age }  )

	//Trailing Lambda means If Function has last argument lambda
	// Then paranthese can be skipped

	//val max2 = people.maxBy { p: Person -> p.age } 
	//println(max1)
	//println(max2)


	val maxAge = people.maxBy { 
		it.age 
	} 
	
	val maxMarks = people.maxBy { 
		it.marks
	} 
	
	println(maxAge)
	println(maxMarks)
}

val canBeInClub27 = { p: Person -> p.age <= 27 }

fun allAnyCountFind() {
	val people = listOf(Person("Bob", 60, 80), Person("Alice", 29, 90), 
		Person("Ang", 31, 100))
    println(people.all(canBeInClub27))
}

fun allAnyCountFind1() {
    val list = listOf(1, 2, 3)

    println(!list.all { it == 3 })
    println(list.any { it != 3 })
}

fun allAnyCountFind2() {
	val people = listOf(Person("Bob", 60, 80), Person("Alice", 29, 90), 
		Person("Ang", 31, 100))

    println(people.find(canBeInClub27))
}

fun groupBy() {
	val people = listOf(Person("Bob", 60, 80), Person("Alice", 29, 90), 
		Person("Ang", 31, 100))

    println(people.groupBy { it.age })
}



fun findTheOldest(people: List<Person>) {
    var maxAge = 0
    var theOldest: Person? = null
    for (person in people) {
        if (person.age > maxAge) {
            maxAge = person.age
            theOldest = person
        }
    }
    println(theOldest)
}


// //Algorithm Locatlisation(Most Changing Part) -> Invariant -> Polymorphism
// fun List<Person>.max( predicate: (p: Person) -> Boolean ) {
//     var maxAge = 0
//     var theOldest: Person? = null
//     for (person in people) {
//     	if (predicate()) {
//         //if (person.age > maxAge) {
//             maxAge = person.age
//             theOldest = person
//         }
//     }
//     println(theOldest)
// }

fun functionCall() {
	val people = listOf(Person("Bob", 60, 80), Person("Alice", 29, 90), 
		Person("Ang", 31, 100))

    findTheOldest(people)
}


// fun performRequest(
//        url: String,
//        callback: (code: Int, content: String) -> Unit
// ) {
//     /*...*/
// }

// val processLoginURL = { code, content -> /*...*/ }
// val processHomeURL = { code, content -> /*...*/ }

// fun performRequestFunction() {
//     val url = "http://kotl.in"
//     performRequest(url) { code, content -> /*...*/ }
//     performRequest(url) { code, page -> /*...*/ }
// }

//Functions?
//Function is First Class Citizen!

//1. Functiom can be assinged a value
//2. Function can be passed to Function
//3. Function can be returned from Function

//Higer Order Functions
//First Class Citizens!

//Pure Functions
// First Class Citizens and (Inputs, Output) will be Invarian
// This should produce sideeffect.

val outer = "Something External"

//Pure Function!
fun String.filter(predicate: (Char) -> Boolean): String {
	//We are preserving Immuatability... Sqeuence Should Immutable
    val sb = StringBuilder()
    for (index in 0 until length) {
        val element = get(index)
        if (predicate(element)) sb.append(element)
    }

	//if (outer.length()) sp.append("Things")
	//println("Something...")

    return sb.toString()
}

fun playWithStringFilter() {
    println("ab1c".filter { it in 'a'..'z' })

// //DSLs
 //    "ab1c".filter { 
 //    	it in 'a'..'z' 
 //    }
}



fun <T> Collection<T>.joinToStringDefault(
        separator: String = ", ",
        prefix: String = "",
        postfix: String = "",
        transform: ( (T) -> String )? = null
        //transform: (T) -> String = { it.toString() }
): String {
    val result = StringBuilder(prefix)

    for ((index, element) in this.withIndex()) {
        if (index > 0) result.append(separator)
        result.append(transform(element))
    }

    result.append(postfix)
    return result.toString()
}

fun joinToStringDefaultFunction() {
    val letters = listOf("Alpha", "Beta")

    println(letters.joinToStringDefault { it.toLowerCase() })
    println(letters.joinToStringDefault(separator = "! ", postfix = "! ",
           transform = { it.toUpperCase() }))
}



fun main() {
	println("\nFunction: playWithCalculator")
	playWithCalculator()

	println("\nFunction : playWithDoSomething")
	playWithDoSomething()

	println("\nFunction: playWithLambda")
	playWithLambda()

	// println("\nFunction: performRequestFunction")
	// performRequestFunction()

	println("\nFunction: playWithStringFilter")
	playWithStringFilter()
}


