package learnKotlin

import java.io.Serializable

// class Human {
// 	val id: Int = 0
// 	val name: String = ""
// }


// fun playWithHuman() {
// 	val humanObject: Human = Human()

// 	writeToFile(human.id, human.name)
// 	humanObject = null;
// }

interface Clickable {
	fun click()
	fun showOff() = println("I'm Clickable!")
}

interface Focusable {
	fun setFocus(b: Boolean) = println("Focusable setFocus!")
	fun showOff() = println("I'm Focusable")
}

class Button1: Clickable, Focusable {
	override fun click() = println("I'm Button!")

	override fun showOff() {
		super<Focusable>.showOff()
		super<Clickable>.showOff()
	}
}

class RichButton: Clickable {
	fun disable() { }
	//open fun animate() {}
	override fun click() {}
}

fun playWithButton() {
	val buttonObject: Button1 = Button1()
	buttonObject.showOff()	
}


 /* Java */
 //Following Java Code Has Issue...
//It Throws java.io.NotSerializableException


// interface State: Serializable
// interface Persistable { 

// } 
// public class Button implements Persistable {
//     @Override
//     public State restoreState() {
//         return new ButtonState();
//     }

//     @Override
//     public void saveState(State state) { /*...*/ }
    
//     public class ButtonState implements State { /*...*/ }
// }


interface State: Serializable

interface Persistable {
	fun saveInstanceState(state : State) { }
	fun restoreInstanceState() : State? 
}


class Button: Persistable {
	var state: State? = null

	override fun saveInstanceState(state: State) {
		this.state = state
		println("Persist Required State")// Serialize and Storing in LocalStore

	}

	override fun restoreInstanceState(): State? {
		println("Restore Required State") //Read From LocalStore and Deserialize
		return state
	}

	class ButtonState(val clickState: Boolean): State {
		// this@Button
	}
//	class ButtonExtraState(val extraState: String): State
}
//class ButtonState(val clickState: Boolean): State

fun playWithButtonPersistance() {
	val buttonObject = Button()
	val state: State = Button.ButtonState(clickState = true)

	buttonObject.saveInstanceState(state)
	val buttonState: Button.ButtonState = buttonObject.restoreInstanceState() as Button.ButtonState

	println(buttonState)
	println(buttonState.clickState)
}

fun main() {
	println("\nFunction: playWithButton")
	playWithButton()

	println("\nFunction: playWithButtonPersistance")
	playWithButtonPersistance()
}
