
package learnKotlin.PersonStatus

val personUnMarried =  0
val personMarried =  1

