
But what if the extracted function contains a coroutine builder which is invoked on the current scope? In this case suspend modifier on the extracted function is not enough. Making doWorld extension method on CoroutineScope is one of the solutions, but it may not always be applicable as it does not make API clearer.









launches a long-running coroutine in [GlobalScope] that prints “I’m sleeping” twice a second and then returns from the main function after some delay:


  import kotlinx.coroutines.*

  fun main() = runBlocking {
  //sampleStart
      GlobalScope.launch {
          repeat(1000) { i ->
              println("I'm sleeping $i ...")
              delay(500L)
          }
		}
      delay(1300L) // just quit after delay
  //sampleEnd
 }

Active coroutines that were launched in [GlobalScope] do not keep the process alive. They are like daemon threads.





Cancellation is cooperative

Coroutine cancellation is cooperative. A coroutine code has to cooperate to be cancellable.

All the suspending functions in kotlinx.coroutines are cancellable. They check for cancellation of coroutine and throw [CancellationException] when cancelled. However, if a coroutine is working in a computation and does not check for cancellation, then it cannot be cancelled, like the following example shows:

Closing resources with finally
Cancellable suspending functions throw [CancellationException] on cancellation which can be handled in the usual way. For example, try {...} finally {...} expression and Kotlin use function execute their finalization actions normally when a coroutine is cancelled:

Both [join][Job.join] and [cancelAndJoin] wait for all finalization actions to complete,



Any attempt to use a suspending function in the finally block of the previous example causes [CancellationException], because the coroutine running this code is cancelled. Usually, this is not a problem, 


	since all well-behaving 
	closing operations (closing a file, cancelling a job, or closing any kind of a communication channel) are usually non-blocking and do not involve any suspending functions. However, in the rare case when you need to suspend in a cancelled coroutine you can wrap the corresponding code in withContext(NonCancellable) {...} using [withContext] function and [NonCancellable] context as the




The TimeoutCancellationException that is thrown by [withTimeout] is a subclass of [CancellationException].
We have not seen its stack trace printed on the console before. That is because inside a cancelled coroutine CancellationException is considered to be a normal reason for coroutine completion. However, in this example we have used withTimeout right inside the main function. Since cancellation is just an exception, all resources are closed in the usual way. You can wrap the code with timeout in a try {...} catch (e: TimeoutCancellationException) {...} block if you need to do some additional action specifically on any kind of timeout or use the [withTimeoutOrNull] function that is similar to [withTimeout] but returns null on timeout instead of throwing an exception:



Coroutines always execute in some context which is represented by the value of CoroutineContext

The coroutine context is a set of various elements. The main elements are the [Job] of the coroutine, which we’ve seen before, and its dispatcher, which is covered in this section.
                         

Coroutine context includes a coroutine dispatcher (see [CoroutineDispatcher]) that determines what thread or threads
the corresponding coroutine uses for its execution. 

Coroutine dispatcher can confine coroutine execution to a specific thread, dispatch it to a thread pool, or let it run unconfined.

All coroutine builders like [launch] and [async] accept an optional
CoroutineContext parameter that can be used to explicitly specify the dispatcher for new coroutine and other context elements.



When launch { ... } is used without parameters, it inherits the context (and thus dispatcher) from the [CoroutineScope] that it is being launched from. In this case, it inherits the context of the main runBlocking coroutine which runs in the main thread. [Dispatchers.Unconfined] is a special dispatcher that also appears to run in the main thread, but it is, in fact, a different mechanism that is explained later.

The default dispatcher, that is used when coroutines are launched in [GlobalScope], is represented by [Dispatchers.Default] and uses shared background pool of threads, so launch(Dispatchers.Default) { ... } uses the same dispatcher as GlobalScope.launch { ... }. [newSingleThreadContext] creates a thread for the coroutine to run. A dedicated thread is a very expensive resource.

In a real application it must be either released, when no longer needed, using [close] [ExecutorCoroutineDispatcher.close] function, or stored in a top-level variable and reused throughout the application.






