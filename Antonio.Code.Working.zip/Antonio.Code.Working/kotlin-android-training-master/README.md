# Boost your Android productivity with Kotlin
### Free Online Training: Learn how Kotlin can change the way you develop Android Apps

This repository is the code used as a base for my free online training that you can find at:

[https://antonioleiva.com/kotlin-training](https://antonioleiva.com/kotlin-training)

If you want to start with Kotlin and still not sure how it can make your life easier, join to the next training!

## License

    Copyright 2018 Antonio Leiva

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.